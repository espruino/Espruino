 _____                 _                                                        
|   __|___ ___ ___ _ _|_|___ ___                                                
|   __|_ -| . |  _| | | |   | . |                                               
|_____|___|  _|_| |___|_|_|_|___|                                               
          |_|                                                               
   Copyright 2012 Gordon Williams
                                               
http://www.pur3.co.uk/espruino

This version of Espruino is provided free for personal
use only. This must not be sold either as software or
pre-programmed hardware without the author's permission.

For more information on how to program this onto your
STM32VLDISCOVERY board, please see the website above.
