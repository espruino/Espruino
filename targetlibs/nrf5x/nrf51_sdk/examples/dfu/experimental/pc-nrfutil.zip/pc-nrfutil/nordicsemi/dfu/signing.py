# Copyright (c) 2015 Nordic Semiconductor. All Rights Reserved.
#
# The information contained herein is property of Nordic Semiconductor ASA.
# Terms and conditions of usage are described in detail in NORDIC
# SEMICONDUCTOR STANDARD SOFTWARE LICENSE AGREEMENT.
#
# Licensees are granted free, non-transferable use of the information. NO
# WARRANTY of ANY KIND is provided. This heading must NOT be removed from
# the file.

from ecdsa import SigningKey
from ecdsa.curves import NIST256p
import hashlib
import binascii
from ecdsa.keys import sigencode_string, sigdecode_string

class Signing(object):
    """
    Class for singing of hex-files
    """
    def gen_key(self, filename):
        """
        Generate a new Signing key using NIST P-256 curve
        """
        self.filename = filename
        self.sk = SigningKey.generate(curve=NIST256p)
        
        with open(filename, "w") as sk_file:
            sk_file.write(self.sk.to_pem())
            
        print "Saved private key to %s" % filename
    
    def load_key(self, filename):
        """
        Load signing key (from pem file)
        """
        with open(filename, "r") as sk_file:
            sk_pem = sk_file.read()

        self.sk = SigningKey.from_pem(sk_pem)
        
        sk_hex = "".join(c.encode('hex') for c in self.sk.to_string())
    
    def sign(self, init_packet_data):
        """
        Create signature for init package using P-256 curve and SHA-256 as hashing algorithm
        Returns R and S keys combined in a 64 byte array
        """
        # Add assertion of init_packet
        if self.sk is None:
            raise IllegalStateException("Can't save key. No key created/loaded")
        
        # Sign the init-packet
        signature = self.sk.sign(init_packet_data, hashfunc=hashlib.sha256, sigencode=sigencode_string)
        return signature
        #r, s = sigdecode_string(signature,NIST256p.generator.order())
        #return b"".join( (number_to_string(r), binascii.hexlify(s)) )
        
    def verify(self, init_packet, r, s):
        """
        Verify init packet 
        """
        # Add assertion of init_packet
        if self.sk is None:
            raise IllegalStateException("Can't save key. No key created/loaded")
        
        vk = self.sk.get_verifying_key()
        
        #Combine R/S
        signature = sigencode_string(r, s, NIST256p.generator.order())
        
        #Verify init packet
        res = vk.verify(signature, init_packet, hashfunc=hashlib.sha256)
        
        if res is False:
            print "Failed verification"
            return False
        else:
            print "Verified!"
            return True
    
    def show_vk(self, output_type):
        """
        Show verification key (as hex, code or pem)
        """
        if self.sk is None:
            raise IllegalStateException("Can't show key. No key created/loaded")
    
        if output_type == None:
            raise InvalidArgumentException("Invalid output type for signature.")
        elif output_type == 'hex':
            self.show_vk_hex()
        elif output_type == 'code':
            self.show_vk_code()
        elif output_type == 'pem':
            self.show_vk_pem()
        else:
            raise InvalidArgumentException("Invalid argument. Can't show key")
        
    def show_vk_hex(self):
        """
        Show the verification key as hex
        """
        if self.sk is None:
            raise IllegalStateException("Can't show key. No key created/loaded")
        
        vk = self.sk.get_verifying_key()
        vk_hex = binascii.hexlify(vk.to_string())
        print "Verification key Qx: %s" % vk_hex[0:64]
        print "Verification key Qy: %s" % vk_hex[64:128]
        
    def show_vk_code(self):
        """
        Show the verification key as code
        """
        if self.sk is None:
            raise IllegalStateException("Can't show key. No key created/loaded")
            
        vk = self.sk.get_verifying_key()
        vk_hex = binascii.hexlify(vk.to_string())

        vk_x_separated = ""
        vk_x_str = vk_hex[0:64]
        for i in xrange(0, len(vk_x_str), 2):
            vk_x_separated += "0x" + vk_x_str[i:i+2] + ", "
        vk_x_separated = vk_x_separated[:-2]

        vk_y_separated = ""
        vk_y_str = vk_hex[64:128]
        for i in xrange(0, len(vk_y_str), 2):
            vk_y_separated += "0x" + vk_y_str[i:i+2] + ", "
        vk_y_separated = vk_y_separated[:-2]

        #print vk_hex[0:64]
        #print vk_hex[64:128]
        print "static uint8_t Qx[] = { %s };" % vk_x_separated
        print "static uint8_t Qy[] = { %s };" % vk_y_separated
        
    def show_vk_pem(self):
        """
        Show the verification key as PEM 
        """
        if self.sk is None:
            raise IllegalStateException("Can't show key. No key created/loaded")
            
        vk = self.sk.get_verifying_key()
        vk_pem = vk.to_pem()
        print vk_pem